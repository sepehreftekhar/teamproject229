const express = require('express');
const cors = require('cors');
const { connectToMongoDB } = require('./db');

const TravelCollectionController = require('./controller'); // Renamed the controller to reflect 'TravelCollections'

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

connectToMongoDB();

app.get('/', (req, res, next) => {
  res.json({
    message: 'Welcome to TravelCollections application.' // Updated welcome message
  });
});

app.get('/api/TravelCollections', TravelCollectionController.getAllTravelCollections); // Updated controller methods
app.post('/api/TravelCollections', TravelCollectionController.addTravelCollections);
app.put('/api/TravelCollections/:id', TravelCollectionController.updateTravelCollections);
app.delete('/api/TravelCollections/:id', TravelCollectionController.deleteTravelCollections);

app.listen(PORT, () => {
  console.log(`Server is running: http://localhost:${PORT}/`);
});
